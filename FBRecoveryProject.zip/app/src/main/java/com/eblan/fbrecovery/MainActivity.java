package com.eblan.fbrecovery;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView webView;
    String targetNumber = "";
    Handler handler = new Handler();
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("ادخل رقم الموبايل");
        final EditText input = new EditText(this);
        builder.setView(input);
        builder.setPositiveButton("تشغيل الأتمتة", (dialog, which) -> {
            targetNumber = input.getText().toString();
            webView.loadUrl("https://m.facebook.com");
            startAutomation();
        });
        builder.setCancelable(false);
        builder.show();
    }

    void startAutomation() {
        runnable = new Runnable() {
            @Override
            public void run() {
                String libInject = "javascript:if(typeof Tesseract==='undefined'){var s=document.createElement('script');s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';document.head.appendChild(s);}";
                webView.evaluateJavascript(libInject, null);

                String js = "javascript:(function(){" +
                        "if(window.fbBotActive)return;window.fbBotActive=true;" +
                        "const TARGET='"+targetNumber+"';let last='';" +
                        "setInterval(()=>{" +
                        "if(!document.body)return;const t=document.body.innerText;" +
                        "if(t.includes('Forgotten password')||t.includes('نسيت كلمة المرور')){" +
                        "if(last!=='f'){last='f';const b=Array.from(document.querySelectorAll('a,div,span')).find(e=>e.innerText.includes('Forgotten password')||e.innerText.includes('نسيت كلمة المرور'));if(b)b.click();}return;}" +
                        "if(t.includes('Find your account')||t.includes('Enter your mobile number')){" +
                        "if(last!=='i'){last='i';const i=document.querySelector('input[name=\"email\"]')||document.querySelector('input[type=\"text\"]');if(i&&!i.value){const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(i,TARGET);i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}));setTimeout(()=>{const c=Array.from(document.querySelectorAll('button,div,span')).find(e=>e.innerText==='Continue'||e.innerText==='متابعة');if(c)c.click();},1500);}}return;}" +
                        "if(document.querySelector('input[type=\"password\"]')){" +
                        "if(last!=='p'){last='p';const a=Array.from(document.querySelectorAll('a,button,div,span')).find(e=>e.innerText.includes('Try another way')||e.innerText.includes('جرب طريقة أخرى'));if(a)a.click();}return;}" +
                        "if(t.includes('Choose a way to log in')||t.includes('اختر طريقة تسجيل الدخول')){" +
                        "if(last!=='c'){last='c';const s=Array.from(document.querySelectorAll('div')).find(e=>{const x=e.innerText||'';return x.includes('SMS')&&(x.includes(TARGET)||x.includes('88')||x.includes('08'));});if(s){s.click();setTimeout(()=>{const c=Array.from(document.querySelectorAll('button,div,span')).find(e=>e.innerText==='Continue'||e.innerText==='متابعة');if(c)c.click();},1000);}}return;}" +
                        "if(t.includes('Before we send the code')||t.includes('أدخل هذه الحروف')){" +
                        "if(last!=='k'){last='k';const img=document.querySelector('img[src*=\"captcha\"],img[src*=\"blob\"],div[role=\"img\"] img');const i=document.querySelector('input[name=\"captcha_response\"],input[placeholder*=\"Enter the letters\"],input[placeholder*=\"الحروف\"]');" +
                        "if(img&&i&&!i.value&&typeof Tesseract!=='undefined'){const c=document.createElement('canvas');const x=c.getContext('2d');const o=new Image();o.crossOrigin='Anonymous';o.onload=()=>{c.width=o.width;c.height=o.height;x.drawImage(o,0,0);const d=c.toDataURL('image/png');Tesseract.recognize(d,'eng').then(({data:{text}})=>{const cl=text.replace(/[^a-zA-Z0-9]/g,'').trim();if(cl.length>=4){const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;s.call(i,cl);i.dispatchEvent(new Event('input',{bubbles:true}));i.dispatchEvent(new Event('change',{bubbles:true}));setTimeout(()=>{const cb=Array.from(document.querySelectorAll('button,div,span')).find(e=>e.innerText==='Continue'||e.innerText==='متابعة');if(cb)cb.click();},1000);}}).catch(e=>console.log(e));};o.src=img.src;}}return;}" +
                        "},2000);})();";
                
                webView.evaluateJavascript(js, null);
                handler.postDelayed(this, 5000);
            }
        };
        handler.post(runnable);
    }
}
